// الاستخدام: npm run user -- email@example.com كلمة_المرور [admin|team]
import { pool, init, upsertUser } from "../lib.js";
const [email, password, role = "team"] = process.argv.slice(2);
if (!pool || !email || !password || !["admin", "team"].includes(role) || password.length < 8) {
  console.error("Usage: npm run user -- <email> <password (8+ chars)> [admin|team]  (DATABASE_URL required)");
  process.exit(1);
}
await init();
await upsertUser(email, password, role);
console.log(`OK: ${email.toLowerCase()} (${role})`);
await pool.end();
